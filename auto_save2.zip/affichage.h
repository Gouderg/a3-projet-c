/* ---------------------------------------------- */
/* - Auteur: ILLIEN Victor                      - */
/* - Fichier: affichage.h                       - */
/* - Utilisation: fichier d'entête d'affichage  - */
/* - Version: 1.0                               - */
/* ---------------------------------------------- */
#ifndef AFFICHAGE_H
#define AFFICHAGE_H
#include "define.h"
#include "unistd.h"



void affichage(oxy myOxy);

#endif