#ifndef LECTURE_H
#define LECTURE_H
#include "define.h"
#include "fir.h"
//#include "ftd2xx.h"


absorp lecture(FILE* pf, int* etat);
absorp lectureUSB();

#endif