#ifndef INTEGRATION_H
#define INTEGRATION_H

#include "define.h"
#include "mesure.h"
#include "iir.h"
#include "fir.h"
#include "fichiers.h"
#include "affichage.h"



void integrationTest(char* filename);

#endif