#ifndef AFFICHAGE_H
#define AFFICHAGE_H
#include "define.h"
#include "unistd.h"



void affichage(oxy myOxy);

#endif